-- =============================================
-- E-commerce Database Schema Creation Script
-- SQL Server 2022 with Advanced Features
-- For ATX SQL Transformation Testing
-- =============================================

USE ECommerceDB;
GO

-- Drop existing tables if they exist (for re-deployment)
IF OBJECT_ID('OrderItems', 'U') IS NOT NULL DROP TABLE OrderItems;
IF OBJECT_ID('Orders', 'U') IS NOT NULL DROP TABLE Orders;
IF OBJECT_ID('Products', 'U') IS NOT NULL DROP TABLE Products;
IF OBJECT_ID('Categories', 'U') IS NOT NULL DROP TABLE Categories;
IF OBJECT_ID('Customers', 'U') IS NOT NULL DROP TABLE Customers;
IF OBJECT_ID('AuditLog', 'U') IS NOT NULL DROP TABLE AuditLog;
GO

-- =============================================
-- Categories Table with Hierarchical Structure
-- =============================================
CREATE TABLE Categories (
    CategoryId INT IDENTITY(1,1) NOT NULL,
    Name NVARCHAR(100) NOT NULL,
    ParentCategoryId INT NULL,
    DisplayOrder INT NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedDate DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    ModifiedDate DATETIME2(7) NULL,
    
    -- Primary Key
    CONSTRAINT PK_Categories PRIMARY KEY CLUSTERED (CategoryId),
    
    -- Self-referencing Foreign Key
    CONSTRAINT FK_Categories_ParentCategory 
        FOREIGN KEY (ParentCategoryId) 
        REFERENCES Categories(CategoryId),
    
    -- Check Constraints
    CONSTRAINT CK_Categories_Name_NotEmpty 
        CHECK (LEN(TRIM(Name)) > 0),
    CONSTRAINT CK_Categories_DisplayOrder_NonNegative 
        CHECK (DisplayOrder >= 0)
);
GO

-- =============================================
-- Products Table with Computed Columns
-- =============================================
CREATE TABLE Products (
    ProductId INT IDENTITY(1,1) NOT NULL,
    Name NVARCHAR(255) NOT NULL,
    Description NVARCHAR(MAX) NULL,
    Price DECIMAL(18,2) NOT NULL,
    CategoryId INT NOT NULL,
    CreatedDate DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    ModifiedDate DATETIME2(7) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    
    -- SQL Server Computed Columns (will test ATX SQL transformation)
    SearchVector AS (Name + ' ' + ISNULL(Description, '')) PERSISTED,
    PriceCategory AS (
        CASE 
            WHEN Price < 50.00 THEN 'Budget'
            WHEN Price < 200.00 THEN 'Standard'
            WHEN Price < 500.00 THEN 'Premium'
            ELSE 'Luxury'
        END
    ) PERSISTED,
    
    -- Primary Key
    CONSTRAINT PK_Products PRIMARY KEY CLUSTERED (ProductId),
    
    -- Foreign Key
    CONSTRAINT FK_Products_Categories 
        FOREIGN KEY (CategoryId) 
        REFERENCES Categories(CategoryId),
    
    -- Check Constraints
    CONSTRAINT CK_Products_Name_NotEmpty 
        CHECK (LEN(TRIM(Name)) > 0),
    CONSTRAINT CK_Products_Price_Positive 
        CHECK (Price > 0),
    CONSTRAINT CK_Products_Price_Reasonable 
        CHECK (Price <= 999999.99)
);
GO

-- =============================================
-- Customers Table with Unique Constraints
-- =============================================
CREATE TABLE Customers (
    CustomerId INT IDENTITY(1,1) NOT NULL,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Email NVARCHAR(255) NOT NULL,
    Phone NVARCHAR(20) NULL,
    CreatedDate DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    ModifiedDate DATETIME2(7) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    
    -- Primary Key
    CONSTRAINT PK_Customers PRIMARY KEY CLUSTERED (CustomerId),
    
    -- Unique Constraints
    CONSTRAINT UQ_Customers_Email UNIQUE (Email),
    
    -- Check Constraints
    CONSTRAINT CK_Customers_FirstName_NotEmpty 
        CHECK (LEN(TRIM(FirstName)) > 0),
    CONSTRAINT CK_Customers_LastName_NotEmpty 
        CHECK (LEN(TRIM(LastName)) > 0),
    CONSTRAINT CK_Customers_Email_Format 
        CHECK (Email LIKE '%@%.%' AND LEN(Email) > 5),
    CONSTRAINT CK_Customers_Phone_Format 
        CHECK (Phone IS NULL OR LEN(Phone) >= 10)
);
GO

-- =============================================
-- Orders Table with Complex Business Logic
-- =============================================
CREATE TABLE Orders (
    OrderId INT IDENTITY(1,1) NOT NULL,
    CustomerId INT NOT NULL,
    OrderDate DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    TotalAmount DECIMAL(18,2) NOT NULL,
    TaxAmount DECIMAL(18,2) NOT NULL,
    Status NVARCHAR(20) NOT NULL DEFAULT 'Pending',
    ShippingAddress NVARCHAR(500) NULL,
    CreatedDate DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    ModifiedDate DATETIME2(7) NULL,
    
    -- Primary Key
    CONSTRAINT PK_Orders PRIMARY KEY CLUSTERED (OrderId),
    
    -- Foreign Key
    CONSTRAINT FK_Orders_Customers 
        FOREIGN KEY (CustomerId) 
        REFERENCES Customers(CustomerId),
    
    -- Check Constraints
    CONSTRAINT CK_Orders_TotalAmount_Positive 
        CHECK (TotalAmount > 0),
    CONSTRAINT CK_Orders_TaxAmount_NonNegative 
        CHECK (TaxAmount >= 0),
    CONSTRAINT CK_Orders_TaxAmount_Reasonable 
        CHECK (TaxAmount <= TotalAmount * 0.5), -- Max 50% tax
    CONSTRAINT CK_Orders_Status_Valid 
        CHECK (Status IN ('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled', 'Refunded')),
    CONSTRAINT CK_Orders_OrderDate_NotFuture 
        CHECK (OrderDate <= GETUTCDATE())
);
GO

-- =============================================
-- OrderItems Table with Computed LineTotal
-- =============================================
CREATE TABLE OrderItems (
    OrderItemId INT IDENTITY(1,1) NOT NULL,
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    
    -- SQL Server Computed Column
    LineTotal AS (Quantity * UnitPrice) PERSISTED,
    
    CreatedDate DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    
    -- Primary Key
    CONSTRAINT PK_OrderItems PRIMARY KEY CLUSTERED (OrderItemId),
    
    -- Foreign Keys
    CONSTRAINT FK_OrderItems_Orders 
        FOREIGN KEY (OrderId) 
        REFERENCES Orders(OrderId) 
        ON DELETE CASCADE,
    CONSTRAINT FK_OrderItems_Products 
        FOREIGN KEY (ProductId) 
        REFERENCES Products(ProductId),
    
    -- Check Constraints
    CONSTRAINT CK_OrderItems_Quantity_Positive 
        CHECK (Quantity > 0),
    CONSTRAINT CK_OrderItems_Quantity_Reasonable 
        CHECK (Quantity <= 1000),
    CONSTRAINT CK_OrderItems_UnitPrice_Positive 
        CHECK (UnitPrice > 0),
    
    -- Unique Constraint (one product per order)
    CONSTRAINT UQ_OrderItems_OrderId_ProductId 
        UNIQUE (OrderId, ProductId)
);
GO

-- =============================================
-- AuditLog Table for Trigger Testing
-- =============================================
CREATE TABLE AuditLog (
    AuditLogId INT IDENTITY(1,1) NOT NULL,
    TableName NVARCHAR(50) NOT NULL,
    Action NVARCHAR(10) NOT NULL,
    RecordId INT NULL,
    UserId NVARCHAR(128) NOT NULL DEFAULT SUSER_SNAME(),
    Timestamp DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    OldValues NVARCHAR(MAX) NULL,
    NewValues NVARCHAR(MAX) NULL,
    
    -- Primary Key
    CONSTRAINT PK_AuditLog PRIMARY KEY CLUSTERED (AuditLogId),
    
    -- Check Constraints
    CONSTRAINT CK_AuditLog_Action_Valid 
        CHECK (Action IN ('INSERT', 'UPDATE', 'DELETE')),
    CONSTRAINT CK_AuditLog_TableName_NotEmpty 
        CHECK (LEN(TRIM(TableName)) > 0)
);
GO

-- =============================================
-- Additional SQL Server Specific Features
-- =============================================

-- Create a table with XML data type (SQL Server specific)
CREATE TABLE ProductSpecifications (
    SpecificationId INT IDENTITY(1,1) NOT NULL,
    ProductId INT NOT NULL,
    SpecificationXML XML NOT NULL,
    CreatedDate DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    
    CONSTRAINT PK_ProductSpecifications PRIMARY KEY (SpecificationId),
    CONSTRAINT FK_ProductSpecifications_Products 
        FOREIGN KEY (ProductId) 
        REFERENCES Products(ProductId) 
        ON DELETE CASCADE
);
GO

-- Create a table with HIERARCHYID data type (SQL Server specific)
CREATE TABLE OrganizationStructure (
    NodeId INT IDENTITY(1,1) NOT NULL,
    OrgNode HIERARCHYID NOT NULL,
    NodeLevel AS OrgNode.GetLevel(),
    DepartmentName NVARCHAR(100) NOT NULL,
    ManagerId INT NULL,
    
    CONSTRAINT PK_OrganizationStructure PRIMARY KEY (NodeId),
    CONSTRAINT UQ_OrganizationStructure_OrgNode UNIQUE (OrgNode)
);
GO

-- Create a table with GEOGRAPHY data type (SQL Server specific)
CREATE TABLE StoreLocations (
    StoreId INT IDENTITY(1,1) NOT NULL,
    StoreName NVARCHAR(100) NOT NULL,
    Address NVARCHAR(500) NOT NULL,
    Location GEOGRAPHY NULL,
    CreatedDate DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    
    CONSTRAINT PK_StoreLocations PRIMARY KEY (StoreId)
);
GO

-- =============================================
-- SQL Server Specific Indexes and Features
-- =============================================

-- Columnstore Index (SQL Server specific)
CREATE NONCLUSTERED COLUMNSTORE INDEX IX_AuditLog_Columnstore
ON AuditLog (TableName, Action, Timestamp, UserId);
GO

-- Filtered Index (SQL Server specific)
CREATE NONCLUSTERED INDEX IX_Products_Active_Price
ON Products (Price, CategoryId)
WHERE IsActive = 1;
GO

-- Index with INCLUDE columns (SQL Server specific)
CREATE NONCLUSTERED INDEX IX_Orders_Customer_Status
ON Orders (CustomerId, Status)
INCLUDE (OrderDate, TotalAmount, TaxAmount);
GO

-- Full-Text Index (SQL Server specific)
CREATE FULLTEXT INDEX ON Products (Name, Description)
KEY INDEX PK_Products
ON ECommerceCatalog;
GO

PRINT 'Database schema created successfully with SQL Server specific features!';
PRINT 'Tables created: Categories, Products, Customers, Orders, OrderItems, AuditLog';
PRINT 'Additional tables: ProductSpecifications, OrganizationStructure, StoreLocations';
PRINT 'SQL Server features: Computed columns, XML data type, HIERARCHYID, GEOGRAPHY, Columnstore index, Full-text search';
GO